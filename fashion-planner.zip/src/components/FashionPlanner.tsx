import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";

interface Task {
  id: number;
  text: string;
  completed: boolean;
}

const FashionPlanner = ({ onBack }: { onBack: () => void }) => {
  const [tasks, setTasks] = useState<Task[]>([
    { id: 1, text: "Stock new pure silk collection", completed: false },
    { id: 2, text: "Review designer portfolio", completed: true },
    { id: 3, text: "Contact logistics for delayed fabric", completed: false },
  ]);
  const [input, setInput] = useState("");

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    setTasks([...tasks, { id: Date.now(), text: input, completed: false }]);
    setInput("");
  };

  const toggleTask = (id: number) => {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)));
  };

  const deleteTask = (id: number) => {
    setTasks(tasks.filter((t) => t.id !== id));
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 animate-fade-in">
      <div className="w-full max-w-lg rounded-2xl bg-card border border-border shadow-xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <Button variant="ghost" onClick={onBack} className="text-primary font-bold">
            ← Home
          </Button>
          <span className="text-sm text-muted-foreground">Roll No: 24071A05G8</span>
        </div>

        {/* Title */}
        <div className="text-center py-6">
          <span className="text-5xl">👗</span>
          <h1 className="text-2xl font-bold text-foreground mt-2">Fashion Planner</h1>
          <p className="text-muted-foreground text-sm">Boutique Management Todo App</p>
        </div>

        {/* Add Task */}
        <form onSubmit={addTask} className="flex mx-4 mb-4 rounded-xl border border-border bg-card overflow-hidden">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Add new fashion management task..."
            className="border-0 focus-visible:ring-0 flex-1"
          />
          <Button type="submit" className="rounded-none rounded-r-xl">
            Add
          </Button>
        </form>

        {/* Task List */}
        <div className="px-4 pb-6 space-y-2">
          {tasks.map((task) => (
            <div
              key={task.id}
              className="flex items-center gap-3 p-3 rounded-xl bg-muted/50 border border-border"
            >
              <Checkbox
                checked={task.completed}
                onCheckedChange={() => toggleTask(task.id)}
              />
              <span
                className={`flex-1 ${task.completed ? "line-through text-muted-foreground" : "text-foreground"}`}
              >
                {task.text}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => deleteTask(task.id)}
                className="bg-accent text-accent-foreground border-accent hover:bg-destructive hover:text-destructive-foreground"
              >
                Delete
              </Button>
            </div>
          ))}
          {tasks.length === 0 && (
            <div className="text-center py-8">
              <span className="text-4xl">✨</span>
              <p className="text-muted-foreground mt-2">All fashion tasks completed!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FashionPlanner;
