import { useState } from "react";
import FashionPlanner from "@/components/FashionPlanner";

const Index = () => {
  const [isOpen, setIsOpen] = useState(false);

  if (isOpen) {
    return <FashionPlanner onBack={() => setIsOpen(false)} />;
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <button
        onClick={() => setIsOpen(true)}
        className="flex flex-col items-center gap-4 transition-transform hover:scale-105 cursor-pointer group"
      >
        <div className="w-28 h-28 rounded-3xl bg-card border border-border shadow-lg flex items-center justify-center text-5xl group-hover:shadow-xl transition-shadow">
          👗
        </div>
        <span className="text-lg font-semibold text-foreground">Fashion Planner</span>
      </button>
    </div>
  );
};

export default Index;
